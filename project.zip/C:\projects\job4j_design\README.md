# job4j_design

Параметризованные типы, Wildcard
Итераторы
Внутреннее устройство:
Коллекции List
Коллекции Stack, Queue
Коллекции Set
Коллекции Map
Структуры Tree
Hashcode, equals